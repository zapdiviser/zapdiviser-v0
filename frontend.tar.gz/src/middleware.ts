export { default } from "next-auth/middleware"

export const config = { matcher: ["/((?!api|static|favicon.ico|login|cadastro).*)"] }
